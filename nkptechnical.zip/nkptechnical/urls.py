from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('nkptechnical_web.urls')),
    path('fnopulse/', include('fnopulse.urls'))
]
