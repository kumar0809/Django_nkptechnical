from django.db import models

# Create your models here.
class user(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=100)
    ph_number = models.IntegerField()
    ref_code = models.CharField(max_length=20)
    password = models.CharField(max_length=30)
    subscribed = models.BooleanField()
    subsc_type = models.CharField(max_length=10)
    subsc_start_dt = models.DateField()
    subsc_end_dt = models.DateField()
