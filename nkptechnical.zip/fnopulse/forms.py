from django import forms


class SignUpValiation(forms.Form):
    InputName1 = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}), min_length=4)
    InputEmail1 = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control'}))
    Inputphone1 = forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control'}))
    InputPassword1 = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control'}), min_length=8)
    InputPassword2 = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control'}), min_length=8)

    def clean_name(self):
        InputName1 = self.cleaned_data.get('InputName1')
        return InputName1

