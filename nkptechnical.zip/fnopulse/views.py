import json

from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.core.mail import send_mail
from .forms import SignUpValiation
# Create your views here.
from .models import user


def dashboard(request):
    return render(request, 'fnopulse/dashboard.html', {})


def register(request):
    if request.method == "POST":
        fm = SignUpValiation(request.POST)
        InputName1 = request.POST['InputName1']
        InputEmail1 = request.POST['InputEmail1']
        Inputphone1 = request.POST['Inputphone1']
        InputRcode1 = request.POST['InputRcode1']
        InputPassword1 = request.POST['InputPassword1']
        from django.contrib.auth.models import User
        x= User.objects.create_user(username=InputEmail1, first_name=InputName1, email=InputEmail1, password=InputPassword1)
        x.save()
        y= user(name=InputName1, email=InputEmail1, ph_number=Inputphone1, ref_code=InputRcode1, password=InputPassword1, subscribed=0)
        y.save()
        return redirect('login')
    else:
        return render(request, 'fnopulse/register.html', {})


def login(request):
    if request.method == "POST":
        InputEmail1 = request.POST['InputEmail1']
        InputPassword1 = request.POST['InputPassword1']
        from django.contrib import auth
        user=auth.authenticate(username=InputEmail1, password=InputPassword1)
        if user is not None:
            auth.login(request, user)
            print("login-in")
            return redirect('dashboard')
        else:
            print("login-out")
            return redirect('index')
    else:
        if request.user.is_authenticated:
            print("login-in")
            return redirect('dashboard')
        else:
            return render(request, 'fnopulse/login.html', {})


def forgot(request):
    return render(request, 'fnopulse/forgot-password.html', {})


def logout(request):
    from django.contrib import auth
    auth.logout(request)
    return redirect('/')


def dashboard(request):
    return render(request, 'fnopulse/dashboard.html', {})
