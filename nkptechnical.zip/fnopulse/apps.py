from django.apps import AppConfig


class FnopulseConfig(AppConfig):
    name = 'fnopulse'
