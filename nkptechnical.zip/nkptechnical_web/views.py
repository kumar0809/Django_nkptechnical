import json

from django.shortcuts import render
from django.http import HttpResponse
from .forms import ContactValiation
from django.core.mail import send_mail


# Create your views here.
def index(request):
    return render(request, 'index.html', {})


def about(request):
    return render(request, 'about.html', {})


def services(request):
    return render(request, 'services.html', {})


def pricing(request):
    return render(request, 'pricing.html', {})


def contact(request):
    if request.method == "POST" and request.is_ajax():
        fm = ContactValiation(request.POST)
        if fm.is_valid():
            msg_name = request.POST['name']
            msg_email = request.POST['email']
            msg_subject = request.POST['subject']
            message = request.POST['message']
            # send an email
            send_mail(
                msg_subject + '- ' + msg_name,  #subject
                message,  #message
                msg_email, # from email
                ['admin@nkptechnical.com'],  # to email
            )
            print('after post')
            data = 'OK'
            return HttpResponse('OK')
        else:
            data = 'ERROR'
            return HttpResponse('Message was not Sent')
    else:
        form = ContactValiation()
        print('before post')
        return render(request, 'contact.html', {})


def disclaimer(request):
    return render(request, 'disclaimer.html', {})


def privacy(request):
    return render(request, 'privacy.html', {})


def refund(request):
    return render(request, 'refund.html', {})


def service1(request):
    return render(request, 'service1.html', {})


def service2(request):
    return render(request, 'service2.html', {})


def service3(request):
    return render(request, 'service3.html', {})


def service4(request):
    return render(request, 'service4.html', {})
