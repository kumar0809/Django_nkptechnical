from django.apps import AppConfig


class NkptechnicalWebConfig(AppConfig):
    name = 'nkptechnical_web'
