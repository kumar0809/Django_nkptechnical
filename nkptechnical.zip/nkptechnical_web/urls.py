"""nkptechnical URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('AboutUs', views.about, name='about'),
    path('Services', views.services, name='services'),
    path('Pricing', views.pricing, name='pricing'),
    path('ContactUs', views.contact, name='contact'),
    path('Service_1', views.service1, name='service1'),
    path('Service_2', views.service2, name='service2'),
    path('Service_3', views.service3, name='service3'),
    path('Service_4', views.service4, name='service4'),
    path('Disclaimer', views.disclaimer, name='disclaimer'),
    path('PrivacyPolicy', views.privacy, name='privacy'),
    path('RefundCancellation', views.refund, name='refund')
]
