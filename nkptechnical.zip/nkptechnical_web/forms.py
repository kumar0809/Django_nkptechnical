from django import forms


class ContactValiation(forms.Form):
    name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}), min_length=4)
    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control'}))
    subject = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}), min_length=4)
    message = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control'}), min_length=4)

    def clean_name(self):
        name = self.cleaned_data.get('name')
        return name

